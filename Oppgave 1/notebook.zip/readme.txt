For å kjøre oppgave må man laste ned jupyter Notebook.
For minst arbeids er det enklest å installere anaconda, der følger jupyter notebook med.
Om ikke kjør 'python3 -m pip install jupyter', det vil da være mulig noen pakker ikke følger med som trengs.

Det ligger også med en PDF fil med kjøringen av notebooken, men ser her noe fra oppgave 2 falt ut etter eksportering. Det som falt ut er utfallet etter histogramspesifikasjon.

Jim-Alexander Gundersen  
